
/*
 * Auto generated Run-Time-Environment Component Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'nrf51-ble-tutorial-advertising' 
 * Target:  'nrf51422_xxac_s130' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


#endif /* RTE_COMPONENTS_H */
